import { Component, OnInit } from '@angular/core';
import { NavController, NavParams } from '@ionic/angular';

interface Product{
  name: string;
  description: string;
}

@Component({
  selector: 'app-create-product',
  templateUrl: './create-product.page.html',
  styleUrls: ['./create-product.page.scss'],
})
export class CreateProductPage implements OnInit {
  myProduct: any;
  constructor(public navCtrl: NavController, public navParams: NavParams) { 
    this.myProduct= {};
  }

  ngOnInit() {
  }

  create(myProduct: Product){
    console.log('myProduct= ', myProduct);
  }

}
